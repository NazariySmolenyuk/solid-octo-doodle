﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Lab6
{
    class MyClass
    {
        public void MyTask()
        {
            Console.WriteLine("MyTask() starting");
            for (int count = 0; count < 10; count++)
            {
                Thread.Sleep(500);
                Console.WriteLine("In MyTask(), count is " + count);
                Console.WriteLine("MyTask terminating");
            }
        }
        class DemoTask
        {
            static void Main()
            {
                Console.WriteLine("Main thread starting.");
                // Construct a MyClass object.
                MyClass mc = new MyClass();
                Task tsk = new Task(mc.MyTask);
                tsk.Start();
                for (int i = 0; i < 60; i++)
                {
                    Console.Write(".");
                    Thread.Sleep(100);
                }
                Console.WriteLine("Main thread ending.");
                Console.ReadKey();
            }
        }
    }
}