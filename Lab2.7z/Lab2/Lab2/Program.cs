﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    abstract class Shapesclass
    {
        abstract public int Area();
    }
    class Square : Shapesclass
    {
        int side = 0;
        public Square(int n) { side = n; }
        // метод Area для уникнення помилки компіляції
        public override int Area() { return side * side; }
        static void Main()
        {
            Square sq = new Square(12);
            Console.WriteLine("Площа квадрата = {0}", sq.Area());
        }
        interface I
        { void M(); }
        abstract class C : I
        { public abstract void M(); }
        // результат: Площа квадрата = 144
    }
}