﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public interface ISeries
    {
        int GetNext(); void Reset();
        void SetStart(int x);
    }
    class ByTwos : ISeries
    {
        int start;
        int val;
        public ByTwos() { start = 0; val = 0; }
        public int GetNext() { val += 2; return val; }
        public void Reset() { val = start; }
        public void SetStart(int x) { start = x; val = start; }
    }
    class Primes : ISeries
    {
        int start;
        int val;
        public Primes() { start = 2; val = 2; }
        public int GetNext()
        {
            int i, j; bool isprime;
            val++; for (i = val; i < 1000000; i++)
            {
                isprime = true;
                for (j = 2; j <= i / j; j++)
                {
                    if ((i % j) == 0) { isprime = false; break; }
                }
                if (isprime) { val = i; break; }
            }
            return val;
        }
        public void Reset() { val = start; }
        public void SetStart(int x) { start = x; val = start; }
    }
    namespace interface_ex4
    {
        class Program
        {
            static void Main(string[] args)
            {
                ByTwos twoOb = new ByTwos();
                Primes primeOb = new Primes();
                ISeries ob;
                for (int i = 0; i < 5; i++)
                {
                    ob = twoOb;
                    Console.WriteLine("Наступне парне число дорiвнює:" + ob.GetNext());
                    ob = primeOb;
                    Console.WriteLine("Наступне просте число дорiвнює:" + ob.GetNext());
                }
                Console.ReadKey();
            }
        }
    }
}