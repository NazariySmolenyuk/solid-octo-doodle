﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7
{
    delegate void MyEventHandler();
    class MyEvent
    {
        public event MyEventHandler SomeEvent;
        public void OnSomeEvent()
        { if (SomeEvent != null) SomeEvent(); }
    }
    class EventDemo
    {
        static void Handler()
        {
            Console.WriteLine("Произошло событие");
            Console.ReadLine();
        }
        public static void Main()
        {
            MyEvent evt = new MyEvent();
            evt.SomeEvent += Handler;
            evt.OnSomeEvent();
        }
    }
}