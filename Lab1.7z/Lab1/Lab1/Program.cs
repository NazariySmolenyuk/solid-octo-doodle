﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }
    }
    class Program
    {
        static void Main()
        {
            Person person1 = new Person("Семен", 26);
            Console.WriteLine("person1 Iм’я = {0} Вiк = {1}", person1.Name, person1.Age); // створення нової персони
            Person person2 = person1; // зміна імені person2, і person1 також зміниться
            person2.Name = "Марiчка";
            person2.Age = 16;
            Console.WriteLine("person2 Iм’я = {0} Вiк = {1}", person2.Name, person2.Age);
            Console.WriteLine("person1 Iм’я = {0} Вiк = {1}", person1.Name, person1.Age);
            Console.ReadKey();
        }
    }
    /*
     Результат:
     person1 Name = Семен Вік = 26
     person2 Name = Марічка Вік = 16
     person1 Name = Марічка Вік = 16
    */
}
