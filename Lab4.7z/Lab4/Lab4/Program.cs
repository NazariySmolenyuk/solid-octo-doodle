﻿using System;
// Оголосити тип делегата.
delegate string StrMod(string str);
class StringOps
{
    public string ReplaceSpaces(string s)
    {
        Console.WriteLine("Замiна пробiлiв дефiсами.");
        return s.Replace(' ', '-');
    }
    public string RemoveSpaces(string s)
    {
        string temp = "";
        int i;
        Console.WriteLine("Видалення пробiлiв.");
        for (i = 0; i < s.Length; i++)
            if (s[i] != ' ') temp += s[i];
        return temp;
    }
    public string Reverse(string s)
    {
        string temp = "";
        int i, j;
        Console.WriteLine("Iнвертування рядка.");
        for (j = 0, i = s.Length - 1; i >= 0; i--, j++)
            temp += s[i]; return temp;
    }
}
class DelegateTest
{
    static void Main()
    {
        StringOps so = new StringOps();
        StrMod strOp = so.ReplaceSpaces;
        string str;
        str = strOp("Це простий тест.");
        Console.WriteLine("Результуючий рядок: " + str);
        Console.WriteLine();
        strOp = so.RemoveSpaces;
        str = strOp("Це простий тест.");
        Console.WriteLine("Результуючий рядок: " + str);
        Console.WriteLine();
        strOp = so.Reverse;
        str = strOp("Це простий тест.");
        Console.WriteLine("Результуючий рядок: " + str);
    }
}